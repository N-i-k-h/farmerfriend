
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

mongoose.connect('mongodb://127.0.0.1:27017/userDB')
    .then(() => {
        console.log('MongoDB connected');
    })
    .catch((err) => {
        console.log('Error connecting to MongoDB:', err);
    });


app.use(bodyParser.urlencoded({ extended: true }));


app.use(express.static(__dirname)); 


const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    agriculture: String,
    password: String,
    phone: String
});

const User = mongoose.model('User', userSchema);


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));  
});


app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'register.html'));  
});


app.post('/register', async (req, res) => {
    try {
        const { name, email, agriculture, password, phone } = req.body;

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.send('Email already exists, please login.');
        }

        
        const newUser = new User({ name, email, agriculture, password, phone });
        await newUser.save();

      
        res.redirect('/login');
    } catch (error) {
        console.error('Error during registration:', error);
        res.status(500).send('Server error during registration');
    }
});


app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));  
});


app.post('/login', async (req, res) => {
    try {
        const { name, password } = req.body;

        
        const user = await User.findOne({ name });

        if (!user || user.password !== password) {
            return res.send('Invalid login credentials');
        }

       
        res.sendFile(path.join(__dirname, 'success.html')); 
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).send('Server error during login');
    }
});


app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
